
// EXERCISE 3 - 5 
//  S
//  U
//  B
//  M
//  I
//  T
//  T
//  E
//  D BY " J E R S O N  R A Y B. D E S I E R T O "


const userModel ={
    name:'',
    email:'',
    password:'',
    isLoggedIn:false,
    data:[],
}

export default userModel;